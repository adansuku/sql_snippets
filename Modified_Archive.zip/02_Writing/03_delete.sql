/*
DELETE
Lección 11.3: https://youtu.be/OuJerKzV5T0?t=10920
*/

-- Elimina el registro de la tabla "customers" con identificador igual a 11
DELETE FROM customers WHERE customer_id = 11;