/*
INNER JOIN (JOIN)
Lección 17.1: https://youtu.be/OuJerKzV5T0?t=16101
*/

-- Realiza un JOIN de manera incorrecta, ya que no existe un campo de relación
SELECT * FROM customers
INNER JOIN dni;

-- Obtiene los datos de los usuarios que tienen un dni 
SELECT * FROM customers
INNER JOIN dni
ON customers.customer_id = dni.customer_id;

-- Obtiene los datos de los usuarios que tienen un dni (JOIN es lo mismo que INNER JOIN)
SELECT * FROM customers
JOIN dni
ON customers.customer_id = dni.customer_id;

-- Obtiene el nombre y el dni de los usuarios que tienen un dni y los ordena por edad
SELECT customer_name, dni_number FROM customers
JOIN dni
ON customers.customer_id = dni.customer_id
ORDER BY age ASC;

-- Obtiene los datos de los usuarios que tienen empresa
SELECT * FROM customers
JOIN companies
ON customers.company_id = companies.company_id;

-- Obtiene los datos de las empresas que tienen usuarios
SELECT * FROM companies
JOIN customers
ON customers.company_id = companies.company_id;

-- Obtiene el nombre de las empresas junto al nombre de sus usuarios
SELECT companies.customer_name, customers.customer_name FROM companies
JOIN customers
ON companies.company_id = customers.company_id;

-- Obtiene los nombres de usuarios junto a los lenguajes que conocen
SELECT customers.customer_name, languages.customer_name
FROM customers_languages
JOIN customers ON customers_languages.customer_id=customers.customer_id
JOIN languages ON customers_languages.language_id=languages.language_id;

-- Obtiene los nombres de usuarios junto a los lenguajes que conocen (utilizando otro orden de relación entre tablas)
SELECT customers.customer_name, languages.customer_name
FROM customers
JOIN customers_languages ON customers.customer_id=customers_languages.customer_id
JOIN languages ON customers_languages.language_id=languages.language_id;