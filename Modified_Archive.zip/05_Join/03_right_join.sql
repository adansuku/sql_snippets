/*
RIGHT JOIN
Lección 17.3: https://youtu.be/OuJerKzV5T0?t=17399
*/

-- Obtiene todos los dni junto a su usuario (lo tenga o no)
SELECT * FROM customers
RIGHT JOIN dni
ON customers.customer_id = dni.customer_id;

-- Obtiene todos los dni junto al nombre de su usuario (lo tenga o no)
SELECT customer_name, dni_number FROM customers
RIGHT JOIN dni
ON customers.customer_id = dni.customer_id;

-- Obtiene el nombre de todos los usuarios junto a su dni (lo tenga o no)
SELECT customer_name, dni_number FROM dni
RIGHT JOIN customers
ON customers.customer_id = dni.customer_id;

-- Obtiene el nombre de todos los lenguajes junto a sus usuarios (los tenga o no)
SELECT customers.customer_name, languages.customer_name
FROM customers
RIGHT JOIN customers_languages ON customers.customer_id=customers_languages.customer_id
RIGHT JOIN languages ON customers_languages.language_id=languages.language_id;