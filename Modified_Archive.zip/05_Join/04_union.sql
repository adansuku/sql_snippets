/*
UNION (FULL JOIN)
Lección 17.4: https://youtu.be/OuJerKzV5T0?t=17536
*/

-- UNION elimina duplicados

-- Obtiene todos los id de usuarios de las tablas dni y usuarios (exista o no relación)
SELECT customers.customer_id AS u_customer_id, dni.customer_id AS d_customer_id
FROM customers
LEFT JOIN dni
ON customers.customer_id = dni.customer_id
UNION
SELECT customers.customer_id AS customer_id, dni.customer_id AS d_customer_id
FROM customers
RIGHT JOIN dni
ON customers.customer_id = dni.customer_id;

-- Obtiene todos los datos de las tablas dni y usuarios (exista o no relación)
SELECT *
FROM customers
LEFT JOIN dni
ON customers.customer_id = dni.customer_id
UNION
SELECT *
FROM customers
RIGHT JOIN dni
ON customers.customer_id = dni.customer_id;

-- UNION ALL mantiene duplicados