/*
LEFT JOIN
Lección 17.2: https://youtu.be/OuJerKzV5T0?t=17045
*/

-- Obtiene los datos de todos los usuarios junto a su dni (lo tenga o no)
SELECT * FROM customers
LEFT JOIN dni
ON customers.customer_id = dni.customer_id;

-- Obtiene el nombre de todos los usuarios junto a su dni (lo tenga o no)
SELECT customer_name, dni_number FROM customers
LEFT JOIN dni
ON customers.customer_id = dni.customer_id;

-- Obtiene todos los dni junto al nombre de su usuario (lo tenga o no)
SELECT customer_name, dni_number FROM dni
LEFT JOIN customers
ON customers.customer_id = dni.customer_id;

-- Obtiene el nombre de todos los usuarios junto a sus lenguajes (los tenga o no)
SELECT customers.customer_name, languages.customer_name
FROM customers
LEFT JOIN customers_languages ON customers.customer_id=customers_languages.customer_id
LEFT JOIN languages ON customers_languages.language_id=languages.language_id;