/*
DROP DATABASE
Lección 12.2: https://youtu.be/OuJerKzV5T0?t=11180
*/

-- Elimina la base de datos llamada "test"
DROP DATABASE test;