/*
CREATE DATABASE
Lección 12.1: https://youtu.be/OuJerKzV5T0?t=11064
*/

-- Crea una base de datos llamada "test"
CREATE DATABASE test;