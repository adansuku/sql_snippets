/*
COUNT
Lección 10.4: https://youtu.be/OuJerKzV5T0?t=8043
*/

-- Cuenta cuantas filas contiene la tabla "customers"
Select COUNT(*) FROM customers;

-- Cuenta cuantas filas contienen un dato no nulo en el campo edad de la tabla "customers"
Select COUNT(age) FROM customers;