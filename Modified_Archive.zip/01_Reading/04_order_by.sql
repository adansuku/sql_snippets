/*
ORDER BY
Lección 9.3: https://youtu.be/OuJerKzV5T0?t=6592
*/

-- Ordena todos los datos de la tabla "customers" por edad (ascendente por defecto)
SELECT * FROM customers ORDER BY age;

-- Ordena todos los datos de la tabla "customers" por edad de manera ascendente
SELECT * FROM customers ORDER BY age ASC;

-- Ordena todos los datos de la tabla "customers" por edad de manera descendente
SELECT * FROM customers ORDER BY age DESC;

-- Retrieves all data from the table "customers" con email igual a sara@gmail.com y los ordena por edad de manera descendente
SELECT * FROM customers WHERE email='sara@gmail.com' ORDER BY age DESC;

-- Retrieves all customer_names from the table "customers" con email igual a sara@gmail.com y los ordena por edad de manera descendente
SELECT customer_name FROM customers WHERE email='sara@gmail.com' ORDER BY age DESC;