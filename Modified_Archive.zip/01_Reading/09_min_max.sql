/*
MIN, MAX
Lección 10.3: https://youtu.be/OuJerKzV5T0?t=7834
*/

-- Obtiene el valor menor del campo edad de la tabla "customers"
Select MIN(age) FROM customers;

-- Obtiene el valor mayor del campo edad de la tabla "customers"
Select MAX(age) FROM customers;