/*
NOT, AND, OR
Lección 9.5: https://youtu.be/OuJerKzV5T0?t=7194
*/

-- Obtiene todos datos de la tabla "customers" con email distinto a sara@gmail.com
SELECT * FROM customers WHERE NOT email = 'sara@gmail.com';

-- Obtiene todos datos de la tabla "customers" con email distinto a sara@gmail.com y edad igual a 15
SELECT * FROM customers WHERE NOT email = 'sara@gmail.com' AND age = 15;

-- Obtiene todos datos de la tabla "customers" con email distinto a sara@gmail.com o edad igual a 15
SELECT * FROM customers WHERE NOT email = 'sara@gmail.com' OR age = 15;