/*
DISTINCT
Lección 9.1: https://youtu.be/OuJerKzV5T0?t=6089
*/

-- Obtiene todos los datos distintos entre sí de la tabla "customers"
SELECT DISTINCT * FROM customers;

-- Obtiene todos los valores distintos referentes al atributo edad de la tabla "customers"
SELECT DISTINCT age FROM customers;