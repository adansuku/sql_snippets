/*
IN
Lección 10.7: https://youtu.be/OuJerKzV5T0?t=8335
*/

-- Ordena todos los datos de la tabla "customers" con nombre igual a adan y sara
SELECT * FROM customers WHERE customer_name IN ('Adan', 'sara')