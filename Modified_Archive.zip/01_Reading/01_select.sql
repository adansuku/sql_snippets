/*
SELECT
Lección 8: https://youtu.be/OuJerKzV5T0?t=5618
*/

-- Retrieves all data from the table "customers"
SELECT * FROM customers;

-- Retrieves all customer_names from the table "customers"
SELECT customer_name FROM customers;

-- Retrieves all user IDs and customer_names from the table "customers"
SELECT customer_id, customer_name FROM customers;