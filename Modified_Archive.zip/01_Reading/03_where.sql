/*
WHERE
Lección 9.2: https://youtu.be/OuJerKzV5T0?t=6384
*/

-- Filtra todos los datos de la tabla "customers" con edad igual a 15
SELECT * FROM customers WHERE age = 15;

-- Filtra todos los nombres de la tabla "customers" con edad igual a 15
SELECT customer_name FROM customers WHERE age = 15;

-- Filtra todos los nombres distintos de la tabla "customers" con edad igual a 15
SELECT DISTINCT customer_name FROM customers WHERE age = 15;

-- Filtra todas las edades distintas de la tabla "customers" con edad igual a 15
SELECT DISTINCT age FROM customers WHERE age = 15;