/*
STORED PROCEDURES
Lección 18.4: https://youtu.be/OuJerKzV5T0?t=20033
*/

-- Crea un procedimiento almacenado llamado "p_all_customers" que obtiene todos los datos de "customers"
DELIMITER //
CREATE PROCEDURE p_all_customers()
BEGIN
	SELECT * FROM customers;
END//

-- Invoca al procedimiento almacenado llamado "p_all_customers"
CALL p_all_customers;

-- Crea un procedimiento almacenado llamado "p_age_customers" parametrizado para
-- obtener usuarios con edad variable
DELIMITER //
CREATE PROCEDURE p_age_customers(IN age_param int)
BEGIN
	SELECT * FROM customers WHERE age = age_param;
END//

-- Invoca al procedimiento almacenado llamado "p_age_customers" con un parámetro de valor 30
CALL p_age_customers(30);

-- Elimina el procedimiento almacenado llamado "p_age_customers"
DROP PROCEDURE p_age_customers;