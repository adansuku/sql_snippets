/*
INDEX
Lección 18.1: https://youtu.be/OuJerKzV5T0?t=18219
*/

-- Crea un índice llamado "idx_customer_name" en la tabla "customers" asociado al campo "customer_name"
CREATE INDEX idx_customer_name ON customers(customer_name);

-- Crea un índice único llamado "idx_customer_name" en la tabla "customers" asociado al campo "customer_name"
CREATE UNIQUE INDEX idx_customer_name ON customers(customer_name);

-- Crea un índice llamado "idx_customer_name_surcustomer_name" en la tabla "customers" asociado a los campos "customer_name" y "surcustomer_name"
CREATE UNIQUE INDEX idx_customer_name_surcustomer_name ON customers(customer_name, surcustomer_name);

-- Elimina el índice llamado "idx_customer_name"
DROP INDEX idx_customer_name ON customers;