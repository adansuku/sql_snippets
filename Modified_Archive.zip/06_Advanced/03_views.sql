/*
VIEWS
Lección 18.3: https://youtu.be/OuJerKzV5T0?t=19663
*/

-- Crea unaa vista llamada "v_adult_customers" con los nombres y edades de usuarios de la table "customers"
-- que tienen una edad igual o mayor a 18 años.
CREATE VIEW v_adult_customers AS
SELECT customer_name, age
FROM customers
WHERE age >= 18;

SELECT * FROM v_adult_customers;

-- Elimina la vista llamada "v_adult_customers"
DROP VIEW v_adult_customers;